import os
from dotenv import load_dotenv
from google import genai

load_dotenv()
API_KEY = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")

if not API_KEY:
    raise RuntimeError("Gemini API key not found. Create .env and set GEMINI_API_KEY.")

client = genai.Client(api_key=API_KEY)

def normalize_model_name(name: str) -> str:
    return name.replace("models/", "").strip()

def get_available_generate_models() -> list[str]:
    available = []
    try:
        for model in client.models.list():
            name = normalize_model_name(getattr(model, "name", ""))
            actions = getattr(model, "supported_actions", []) or []
            if name and (not actions or "generateContent" in actions):
                available.append(name)
    except Exception:
        pass
    return available

def choose_model(candidates: list[str]) -> str | None:
    available = set(get_available_generate_models())
    for candidate in candidates:
        if candidate in available:
            return candidate
    for candidate in candidates:
        try:
            client.models.get(model=candidate)
            return candidate
        except Exception:
            continue
    return None

def generate_text(prompt: str, candidates: list[str]) -> str:
    model = choose_model(candidates)
    if not model:
        raise RuntimeError("No compatible Gemini model is available for this API key.")
    response = client.models.generate_content(model=model, contents=prompt)
    text = getattr(response, "text", None)
    if not text:
        raise RuntimeError("Gemini returned an empty response.")
    return text.strip()

def get_model_status() -> dict:
    workout = ["gemini-3.1-pro-preview", "gemini-3.8-flash", "gemini-2.5-pro", "gemini-2.5-flash"]
    nutrition = ["gemini-3.8-flash", "gemini-3.5-flash", "gemini-2.5-flash"]
    available = get_available_generate_models()
    return {"available_models": available, "selected_workout_model": choose_model(workout), "selected_nutrition_model": choose_model(nutrition)}
