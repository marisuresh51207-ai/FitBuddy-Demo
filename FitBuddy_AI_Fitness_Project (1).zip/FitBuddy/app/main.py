from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from .database import create_tables
from .routes import router

app = FastAPI(title="FitBuddy - AI Fitness Plan Generator", description="Personalized workout and nutrition planning with Gemini AI.", version="1.0.0")
create_tables()
app.mount("/static", StaticFiles(directory="app/static"), name="static")
app.include_router(router)
